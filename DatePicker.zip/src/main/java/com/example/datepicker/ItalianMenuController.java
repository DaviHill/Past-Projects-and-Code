package com.example.datepicker;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class ItalianMenuController {

    @FXML
    private Button backButton;

    @FXML
    private Button nextButton;

    @FXML
    void backButton(ActionEvent event) {

    }

    @FXML
    void nextButton(ActionEvent event) {

    }

}
